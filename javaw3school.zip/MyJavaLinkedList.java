package JavaTutorialFromW3Schools;
/*
@author: Tejas Lotlikar (2033)
@version: 1.0
@see: none
*/

//Import the LinkedList class
import java.util.LinkedList;

public class MyJavaLinkedList {
public static void main(String[] args) {
 LinkedList<String> cars = new LinkedList<String>();
 cars.add("Volvo");
 cars.add("BMW");
 cars.add("Ford");
 cars.add("Mazda");
 System.out.println(cars);
}
}

package JavaTutorialFromW3Schools;
/*
@author: Tejas Lotlikar (2033)
@version: 1.0
@see: Dog.java
*/
class Animal {
	  public void animalSound() {
	    System.out.println("The animal makes a sound");
	  }
	}
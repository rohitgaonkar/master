package JavaTutorialFromW3Schools;
/*
@author: Tejas Lotlikar (2033)
@version: 1.0
@see: none
*/
public class MyJavaVariables {
	public static void main(String[] args) {
			// This is a comment
			String name = "John";
			System.out.println(name);
			int myNum = 15;
			System.out.println(myNum);
			myNum = 20;  // myNum is now 20
			System.out.println(myNum);
			
			float myFloatNum = 5.99f;
			char myLetter = 'D';
			boolean myBool = true;
			String myText = "Hello";
	}
}

package JavaTutorialFromW3Schools;
/*
@author: Tejas Lotlikar (2033)
@version: 1.0
@see: none
*/
public class MyJavaOperators {
	 public static void main(String[] args) {
		    int sum1 = 100 + 50;
		    int sum2 = sum1 + 250;
		    int sum3 = sum2 + sum2;
		    System.out.println(sum1);
		    System.out.println(sum2);
		    System.out.println(sum3);  
		    
		    int x = 10;
		    x += 5;
		    System.out.println(x);
		  }
}

package JavaTutorialFromW3Schools;
/*
@author: Tejas Lotlikar (2033)
@version: 1.0
@see: none
*/
public class MyJavaScope {
	public static void main(String[] args) {

	    // Code here CANNOT use x

	    int x = 100;

	    // Code here can use x
	    System.out.println(x);
	  }
	}

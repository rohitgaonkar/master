package JavaTutorialFromW3Schools;
/*
@author: Tejas Lotlikar (2033)
@version: 1.0
@see: none
*/
public class MyJavaForLoop {
	public static void main(String[] args) {
	    for (int i = 0; i < 5; i++) {
	      System.out.println(i);
	    }  
	  }
}

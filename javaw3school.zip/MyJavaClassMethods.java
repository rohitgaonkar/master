package JavaTutorialFromW3Schools;
/*
@author: Tejas Lotlikar (2033)
@version: 1.0
@see: none
*/
public class MyJavaClassMethods {
	static void myMethod() {
	    System.out.println("Hello World!");
	  }

	  public static void main(String[] args) {
	    myMethod();
	  }
}

package JavaTutorialFromW3Schools;
/*
@author: Tejas Lotlikar (2033)
@version: 1.0
@see: none
*/
public class MyJavaWhileLoop {
	 public static void main(String[] args) {
		    int i = 0;
		    while (i < 5) {
		      System.out.println(i);
		      i++;
		    }  
		    
		    i = 0;
		    do {
		      System.out.println(i);
		      i++;
		    }
		    while (i < 5);  
		  }
}

package JavaTutorialFromW3Schools;
/*
@author: Tejas Lotlikar (2033)
@version: 1.0
@see: Dog.java
*/
abstract class Animalabs {
	  public abstract void animalSound();
	  public void sleep() {
	    System.out.println("Zzz");
	  }
	}
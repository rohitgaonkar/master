package JavaTutorialFromW3Schools;
/*
@author: Tejas Lotlikar (2033)
@version: 1.0
@see: Dog.java
*/
//interface
interface Animalint {
public void animalSound(); // interface method (does not have a body)
public void run(); // interface method (does not have a body)
}
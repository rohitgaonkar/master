package JavaTutorialFromW3Schools;
/*
@author: Tejas Lotlikar (2033)
@version: 1.0
@see: none
*/
public class MyJavaIfElse {
	public static void main(String[] args) {
	    int time = 22;
	    if (time < 10) {
	      System.out.println("Good morning.");
	    } else if (time < 20) {
	      System.out.println("Good day.");
	    }  else {
	      System.out.println("Good evening.");
	    }
	  }
}

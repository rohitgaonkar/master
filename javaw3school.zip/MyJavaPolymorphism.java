package JavaTutorialFromW3Schools;
/*
@author: Tejas Lotlikar (2033)
@version: 1.0
@see: Pig.java, Dog.java Animal.java
*/
public class MyJavaPolymorphism {
	public static void main(String[] args) {
	    Animal myAnimal = new Animal();  // Create a Animal object
	    Pig myPig = new Pig();  // Create a Pig object
	    Animal myDog = new Dog();  // Create a Dog object
	    myAnimal.animalSound();
	    myPig.animalSound();
	    myDog.animalSound();
	  }
}

package JavaTutorialFromW3Schools;
/*
@author: Tejas Lotlikar (2033)
@version: 1.0
@see: none
*/
public class MyJavaWrapperClass {
	public static void main(String[] args) {
	    Integer myInt = 5;
	    Double myDouble = 5.99;
	    Character myChar = 'A';
	    System.out.println(myInt);
	    System.out.println(myDouble);
	    System.out.println(myChar);
	  
	
	System.out.println(myInt.intValue());
    System.out.println(myDouble.doubleValue());
    System.out.println(myChar.charValue());
    
    Integer x = 100;
    String myString = x.toString();
    System.out.println(myString.length());
	}
}

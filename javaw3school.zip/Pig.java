package JavaTutorialFromW3Schools;
/*
@author: Tejas Lotlikar (2033)
@version: 1.0
@see: Animalabs.java
*/
class Pig extends Animalabs {
	  public void animalSound() {
	    System.out.println("The pig says: wee wee");
	  }
	}
package JavaTutorialFromW3Schools;
/*
@author: Tejas Lotlikar (2033)
@version: 1.0
@see: none
*/
public class MyJavaHOME {
	  public static void main(String[] args) {
	    System.out.println("Hello World");
	  }
	}
package JavaTutorialFromW3Schools;
/*
@author: Tejas Lotlikar (2033)
@version: 1.0
@see: none
*/
public class MyJavaBooleans {
	public static void main(String[] args) {
	    boolean isJavaFun = true;
	    boolean isFishTasty = false;    
	    System.out.println(isJavaFun);
	    System.out.println(isFishTasty);
	    
	    int x = 10;
	    int y = 9;
	    System.out.println(x > y); // returns true, because 10 is higher than 9  
	    
	    System.out.println(10 > 9); // returns true, because 10 is higher than 9  

	    System.out.println(x == 10); // returns true, because the value of x is equal to 10

	    System.out.println(15 == 10); // returns false, because 10 is not equal to 15

	  }
}

package JavaTutorialFromW3Schools;
/*
@author: Tejas Lotlikar (2033)
@version: 1.0
@see: none
*/
public class MyJavaClassesAndObjects {
	int x = 5;

	  public static void main(String[] args) {
	    MyJavaClassesAndObjects myObj1 = new MyJavaClassesAndObjects();  // Object 1
	    MyJavaClassesAndObjects myObj2 = new MyJavaClassesAndObjects();  // Object 2
	    System.out.println(myObj1.x);
	    System.out.println(myObj2.x);
	  }
}

package JavaTutorialFromW3Schools;
/*
@author: Tejas Lotlikar (2033)
@version: 1.0
@see: none
*/

public class MyJavaEncapsulation {
	public static void main(String[] args) {
	    Person myObj = new Person();
	    myObj.setName("John");
	    System.out.println(myObj.getName());
	  }
}

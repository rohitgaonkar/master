package JavaTutorialFromW3Schools;
/*
@author: Tejas Lotlikar (2033)
@version: 1.0
@see: none
*/

public class MyJavaEnums {
	  enum Level {
	    LOW,
	    MEDIUM,
	    HIGH
	  }

	  public static void main(String[] args) {
	    Level myVar = Level.MEDIUM; 
	    System.out.println(myVar);
	  }
	}
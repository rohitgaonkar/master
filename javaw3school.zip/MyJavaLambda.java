package JavaTutorialFromW3Schools;
/*
@author: Tejas Lotlikar (2033)
@version: 1.0
@see: none
*/
import java.util.function.Consumer;
import java.util.ArrayList;

interface StringFunction {
	  String run(String str);
	}

public class MyJavaLambda {
	public static void main(String[] args) {
	    ArrayList<Integer> numbers = new ArrayList<Integer>();
	    numbers.add(5);
	    numbers.add(9);
	    numbers.add(8);
	    numbers.add(1);
	    numbers.forEach( (n) -> { System.out.println(n); } );
	
	    ArrayList<Integer> numbers1 = new ArrayList<Integer>();
	    numbers1.add(5);
	    numbers1.add(9);
	    numbers1.add(8);
	    numbers1.add(1);
	    Consumer<Integer> method = (n) -> { System.out.println(n); };
	    numbers1.forEach( method );
	    
	    StringFunction exclaim = (s) -> s + "!";
	    StringFunction ask = (s) -> s + "?";
	    printFormatted("Hello", exclaim);
	    printFormatted("Hello", ask);
	    
	    
	}
	public static void printFormatted(String str, StringFunction format) {
        String result = format.run(str);
        System.out.println(result);
      }
}

package JavaTutorialFromW3Schools;
/*
@author: Tejas Lotlikar (2033)
@version: 1.0
@see: none
*/
public class MyJavaComments {
	public static void main(String[] args) {
		// This is a comment
		System.out.println("Hello World");
		/* The code below will print the words Hello World
		to the screen, and it is amazing */
		System.out.println("Hello World");
	}
}

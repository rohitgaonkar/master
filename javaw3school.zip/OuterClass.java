package JavaTutorialFromW3Schools;
/*
@author: Tejas Lotlikar (2033)
@version: 1.0
@see: none
*/
class OuterClass {
	  int x = 10;

	  class InnerClass {
	    int y = 5;
	  }
	}

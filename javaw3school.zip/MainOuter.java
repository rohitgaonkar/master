package JavaTutorialFromW3Schools;
/*
@author: Tejas Lotlikar (2033)
@version: 1.0
@see: none
*/
public class MainOuter {
	  public static void main(String[] args) {
	    OuterClass myOuter = new OuterClass();
	    OuterClass.InnerClass myInner = myOuter.new InnerClass();
	    System.out.println(myInner.y + myOuter.x);
	  }
	}

	// Outputs 15 (5 + 10)
package JavaTutorialFromW3Schools;
/*
@author: Tejas Lotlikar (2033)
@version: 1.0
@see: none
*/
public class MyJavaStrings {
	public static void main(String[] args) {
	    String txt = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
	    System.out.println("The length of the txt string is: " + txt.length());
	    
	    String txt1 = "Hello World";
	    System.out.println(txt1.toUpperCase());   // Outputs "HELLO WORLD"
	    System.out.println(txt1.toLowerCase());   // Outputs "hello world"
	    
	    String txt2 = "Please locate where 'locate' occurs!";
	    System.out.println(txt2.indexOf("locate")); // Outputs 7
	    
	    String firstName = "John";
	    String lastName = "Doe";
	    System.out.println(firstName + " " + lastName);
	    System.out.println(firstName.concat(lastName));

	    String x = "10";
	    String y = "20";
	    String z = x + y;
	    System.out.println(z);
	    
	    
	    String w = "10";
	    int v = 20;
	    String k = w + v;
	    System.out.println(k);
	  }
}

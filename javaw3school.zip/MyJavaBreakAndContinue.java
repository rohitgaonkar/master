package JavaTutorialFromW3Schools;
/*
@author: Tejas Lotlikar (2033)
@version: 1.0
@see: none
*/
public class MyJavaBreakAndContinue {
	public static void main(String[] args) {
	    int i = 0;
	    while (i < 10) {
	      System.out.println(i);
	      i++;
	      if (i == 4) {
	        break;
	      }
	    }
	    i=0;
	    while (i < 10) {
	      if (i == 4) {
	        i++;
	        continue;
	      }
	      System.out.println(i);
	      i++;
	    }  
	  }
}

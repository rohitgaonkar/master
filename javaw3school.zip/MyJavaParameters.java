package JavaTutorialFromW3Schools;
/*
@author: Tejas Lotlikar (2033)
@version: 1.0
@see: none
*/
public class MyJavaParameters {
	static void myMethod(String fname) {
	    System.out.println(fname + " Refsnes");
	  }

	  public static void main(String[] args) {
	    myMethod("Liam");
	    myMethod("Jenny");
	    myMethod("Anja");
	  }
}

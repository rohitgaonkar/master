package JavaTutorialFromW3Schools;
/*
@author: Tejas Lotlikar (2033)
@version: 1.0
@see: none
*/
public class MyJavaArrays {
	public static void main(String[] args) {
	    String[] cars = {"Volvo", "BMW", "Ford", "Mazda"};
	    System.out.println(cars[0]);
	    
	    cars[0] = "Opel";
	    System.out.println(cars[0]);
	    
	    System.out.println(cars.length);

	    for (int i = 0; i < cars.length; i++) {
	    	  System.out.println(cars[i]);
	    	}


	  }
}

package JavaTutorialFromW3Schools;
/*
@author: Tejas Lotlikar (2033)
@version: 1.0
@see: none
*/
public class MyJavaConstructor {
	int modelYear;
	  String modelName;

	  public MyJavaConstructor(int year, String name) {
	    modelYear = year;
	    modelName = name;
	  }

	  public static void main(String[] args) {
		  MyJavaConstructor myCar = new MyJavaConstructor(1969, "Mustang");
	    System.out.println(myCar.modelYear + " " + myCar.modelName);
	  }
}
